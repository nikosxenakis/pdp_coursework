/*
 * Description: This file includes defines of the 3 different actor types
*/

#ifndef ACTOR_TYPES_H
#define ACTOR_TYPES_H

	#define ACTOR_TYPE_CLOCK 0
	#define ACTOR_TYPE_CELL 1
	#define ACTOR_TYPE_SQUIRREL 2

#endif
