var searchData=
[
  ['kill_5factor',['kill_actor',['../class_actor.html#a896f44bf51ff95a8b4cd52c267ba043d',1,'Actor']]],
  ['kill_5fall',['kill_all',['../class_actor.html#a6d7a82eada9840fa746e24f8c30d117f',1,'Actor']]],
  ['kill_5fall_5factors',['kill_all_actors',['../class_worker.html#a08ce32d12de7f15e32a8f090864c00b0',1,'Worker']]]
];
