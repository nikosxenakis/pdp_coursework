var searchData=
[
  ['finalize',['finalize',['../class_master.html#ab7ff20c0bfe0d2aa9dfe638136d6ff31',1,'Master::finalize()'],['../class_worker.html#adc4279dd9c30acb34ac449bad40cf244',1,'Worker::finalize()']]],
  ['find_5factor',['find_actor',['../class_worker.html#a4f171c181dee164c965f708cdf394745',1,'Worker']]]
];
