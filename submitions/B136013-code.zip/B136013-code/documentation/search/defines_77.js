var searchData=
[
  ['worker_5fpid',['WORKER_PID',['../framework__message__types_8h.html#a6a9a27eb983b5315cc6a56e05955e108',1,'framework_message_types.h']]],
  ['workers_5fnum',['WORKERS_NUM',['../framework__message__types_8h.html#ac96c0ae9dd4b3611c682af2c711e36fb',1,'framework_message_types.h']]]
];
