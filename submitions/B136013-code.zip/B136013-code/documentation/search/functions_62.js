var searchData=
[
  ['birth',['birth',['../class_squirrel.html#a0f01466d34249e0e3d4c4fb4b323a889',1,'Squirrel']]]
];
