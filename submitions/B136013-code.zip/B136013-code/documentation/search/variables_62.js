var searchData=
[
  ['begin_5ftime',['begin_time',['../class_clock.html#ad33495e8e1eaccfb603aea59ca4d28ca',1,'Clock::begin_time()'],['../class_squirrel.html#a288a12c5b4e06d052b48616b20206862',1,'Squirrel::begin_time()']]]
];
