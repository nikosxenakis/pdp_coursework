var searchData=
[
  ['next_5factor_5fid',['next_actor_id',['../class_master.html#a9594e71e127515002178ef625193d32b',1,'Master']]]
];
