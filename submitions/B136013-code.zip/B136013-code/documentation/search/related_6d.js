var searchData=
[
  ['messenger',['Messenger',['../class_message.html#aead9207826afb61a91ab87619a6fb1ea',1,'Message']]]
];
