var searchData=
[
  ['workers_5fnum',['workers_num',['../class_actor.html#af3d6fcd533775b0e74f1f69a33c9dcef',1,'Actor::workers_num()'],['../class_master.html#ad9bf0db7eb020430a8913637581bbc71',1,'Master::workers_num()']]]
];
