var searchData=
[
  ['id',['id',['../class_actor.html#a0d2b93f5baefded4573b9f89aa5bda9a',1,'Actor']]],
  ['infected_5fsquirrels',['infected_squirrels',['../class_clock.html#aae773961dd6cc9bf0d5068456e111632',1,'Clock']]],
  ['infected_5fsquirrels_5fstream',['infected_squirrels_stream',['../class_clock.html#a8e707ecd236312267e130b02c0944df2',1,'Clock']]],
  ['infected_5fsteps',['infected_steps',['../class_squirrel.html#a7e8c5d4cf046a9c37fe48a3c8c0d3a3f',1,'Squirrel']]],
  ['infection_5flevel',['infection_level',['../class_cell.html#ad79dc7fae7aa3d38c3e02721a0d25707',1,'Cell::infection_level()'],['../class_clock.html#af352a22d14ebb3000cdb8d7ed9301147',1,'Clock::infection_level()'],['../class_squirrel.html#ab9bf6503f1ec38449d7156f2f7d96e45',1,'Squirrel::infection_level()']]],
  ['infection_5flevel_5fstream',['infection_level_stream',['../class_clock.html#aeb0a5bb5ea2d2678aebdfadb5fd0be2c',1,'Clock']]],
  ['init_5factors',['init_actors',['../class_actor__framework.html#a5acd8b739408e61c209034b98a2ceb7b',1,'Actor_framework']]]
];
