var searchData=
[
  ['actors',['actors',['../class_worker.html#aa2588d255fa07d6fb6b214d4c00aa1d2',1,'Worker']]],
  ['actors_5fdied',['actors_died',['../class_master.html#a3ba81e3ac7fd42a1598e65e63f2cccd6',1,'Master::actors_died()'],['../class_worker.html#a8187a2c3b5df506b284109a00d524775',1,'Worker::actors_died()']]],
  ['actors_5fspawned',['actors_spawned',['../class_worker.html#ac93e2d2e15633642c57867944c7290a5',1,'Worker']]],
  ['alive_5fsquirrels',['alive_squirrels',['../class_clock.html#ab6ce98eacbd135e039145a4ca93636cd',1,'Clock']]],
  ['alive_5fsquirrels_5fstream',['alive_squirrels_stream',['../class_clock.html#aa3ae42a55182e8b382d2592bf9de28f9',1,'Clock']]]
];
