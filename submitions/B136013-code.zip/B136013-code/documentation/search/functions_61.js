var searchData=
[
  ['actor',['Actor',['../class_actor.html#abaad071069461c7d1b48d3d10afbb862',1,'Actor']]],
  ['actor_5fframework',['actor_framework',['../class_actor__framework.html#a02630a7c439eb3983eb28ec46cd3a15d',1,'Actor_framework']]],
  ['add_5factor',['add_actor',['../class_worker.html#a7982a7b9943f5360690cf2dc12087d28',1,'Worker']]]
];
