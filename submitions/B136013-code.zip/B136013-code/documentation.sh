# Exam number: B136013

rm documentation/*;
doxygen;